from django.apps import AppConfig


class HvactodoConfig(AppConfig):
    name = 'HVACtodo'
